# DATASCAPE 2026 run history and results

Last updated 2026-10-06, after run 32. The detailed log with every number is in the Claude memory folder (`project_baseline_results.md`), this file is the readable summary.

## Task and setup

- Competition: DATASCAPE 2026 Data Mining Competition (Kaggle). Classify package condition images as Aman, Rusak or Lainnya. Metric is macro F1.
- Data: 12,224 training images (8,800 Aman, 3,001 Rusak, 423 Lainnya), 3,057 test images. 52 images in 26 identical-file groups with conflicting labels are dropped, leaving 12,172.
- Leaderboard: 30% public and 70% private (private hidden until close). 3 submissions per day, shared with a teammate. Kaggle auto-picks the best 2 by public score.
- Rules that matter: only organizer data, no manual inference on test images, AI declaration needed in the final notebook (not added yet), admin allows fine-tuning CLIP-style encoders.
- Deadline: Friday Oct 9 or 10, 2026. Deliverables are `NamaTim_Notebook.ipynb` and `NamaTim_Writeup.pdf` (writeup not started).
- Pipeline: timm backbone, letterbox to square, weighted sampler, focal loss (gamma 2, no alpha), AdamW, cosine schedule, 5-fold stratified CV with `SEED=42` (never change it, it seeds the folds), best epoch per fold, test predicted by averaging the 5 fold models with horizontal flip.
- Scores below are pooled OOF macro F1 over all 12,172 images with flip probabilities, unless marked otherwise. Runs 1 to 10 used one 15% validation split and are not comparable to the rest.

## Leaderboard scores (public)

| Submission | OOF | Leaderboard | Note |
|---|---|---|---|
| Run 12 (probable match) | 0.7714 | 0.70350 | focal with alpha |
| Run 13 (probable match) | 0.8293 | 0.74062 | convnext_tiny, no shift aug |
| Run 14 plus Lainnya 3x | about 0.826 | 0.72042 | 15 labels changed |
| Run 14 plus stage 2 size model | about 0.826 | 0.72079 | 160 labels changed |
| Blend 23+26+29 (equal) | 0.9203 | 0.79133 | submitted 2026-10-05 |

The gap between OOF and leaderboard is large and grew with better models (0.09 for run 13, 0.13 for the blend). Higher OOF still goes with a higher leaderboard score, so the direction is right even if the size is not.

## Run history

| Run | Backbone and change | Platform | OOF macro F1 | Result |
|---|---|---|---|---|
| 1 to 4 | convnext_tiny, 15 to 50 epochs, early stop tuning | Kaggle | 0.7907 to 0.8381 (single split) | run 4 looked best but was a lucky unseeded roll |
| 5, 6 | mixup and cutmix | Kaggle | 0.7245, 0.6860 | failed, dropped |
| 7 | weight decay 5e-2 | Kaggle | 0.7683 | not worse than the true baseline once nondeterminism was fixed |
| 8 to 10 | same config, seeding and cuDNN determinism fixes | Kaggle | 0.7631, 0.7485, 0.7485 | reproducible baseline is 0.7485, run 10 is byte-identical to run 9 |
| 11 | 5-fold CV, class-weighted CE | Kaggle | 0.7948 | first honest estimate |
| 12 | plus focal loss with alpha | Kaggle | 0.7714 | worse |
| 13 | focal loss gamma 2, no alpha | Kaggle | 0.8293 | best of the early runs |
| 14 | plus drop path 0.1 | Kaggle | 0.8258 | no gain |
| 15 | plus shift augmentation and image cache | Kaggle | 0.7965 | shift aug cost about 0.03 at LR 3e-4 |
| 16 | dedup, convnext_tiny, shift aug | Kaggle | 0.7979 | control for run 17 |
| 17 | efficientnet_b0, same setup | Kaggle | 0.8716 | +0.074 over convnext at LR 3e-4 |
| 18 | efficientnet_b0 Noisy Student weights | Modal | 0.8673 | no gain |
| 19 | efficientnet_b0 at 288 px | Modal | 0.8758 | within noise of run 17 |
| 20 | convnext_tiny at LR 5e-5, no shift aug | Modal | 0.8952 | LR was the problem, big jump |
| 21 | convnext_tiny at LR 3e-5 | Modal | 0.9008 | small gain |
| 22 | run 21 with shift aug | Modal | 0.8962 | shift aug now costs only 0.005 |
| 23 | convnext_small at LR 3e-5 | Modal | 0.9078 | best convnext |
| 24 | DINOv2 small, layer decay 0.75, LR 5e-5 | Kaggle | 0.8989 | different family, no score gain |
| 25 | efficientnet_b0 at low LR 5e-5 | Modal | 0.7749 | failed, effnet needs a high LR |
| 26 | CLIP ViT-B/16 (OpenAI), LR 3e-5, layer decay 0.75 | Kaggle | 0.9131 | best single until run 30 |
| 27 | convnext_small seed 1 on the laptop | laptop | none | stopped, about 40 h projected on a GTX 1650 Ti |
| 28 | CLIP ViT-B/16 LAION-2B weights | Kaggle | 0.9096 | within noise of run 26 |
| 29 | run 26 with shift aug on | Kaggle | 0.9091 | within noise, test calls moved toward Rusak |
| 30 | SigLIP ViT-B/16 (224 px) | Kaggle | 0.9153 | best single until run 32 (0.9167 without TTA) |
| 31 | SigLIP ViT-B/16 at 256 px | Modal | 0.9136 | no gain from resolution |
| 32 | SigLIP 2 ViT-B/16 (224 px) | Kaggle | 0.9183 | best single model (0.9186 without TTA) |

## Blends (equal weights on flip probabilities)

| Blend | OOF | Note |
|---|---|---|
| 14+15 | 0.8278 | early shift aug blend |
| 17+18 | 0.8808 | efficientnet pair |
| 23+21 | 0.9106 | convnext pair |
| 23+24 | 0.9116 | convnext plus DINOv2 |
| 23+26 | 0.9185 | |
| 23+26+28 | 0.9189 | |
| 23+26+29 | 0.9203 | submitted, leaderboard 0.79133 |
| 23+26+29+30 | 0.9225 | |
| 28+29+30 | 0.9232 | picked from a search, optimistic |
| 23+29+30+31 | 0.9248 | picked from a search, optimistic |
| 26+29+30+32 | 0.9261 | picked from a search, optimistic |
| 23+26+29+30+31 | 0.9258 | all members, not searched, +0.0054 over the submitted blend (95% CI +0.0024 to +0.0087) |
| 23+26+29+30+31+32 | 0.9253 | all members, adding run 32 does not help (-0.0005 against the five-way) |

Candidate files not submitted yet are `submission-blend-run23-run26-run29-run30-run31-run32-equal.csv` (1947/1054/56 for Aman/Rusak/Lainnya, 58 labels differ from the submitted blend), `submission-blend-run23-run26-run29-run30-run31-equal.csv` (45 differ) and `submission-blend-run23-run26-run29-run30-run32-equal.csv`. The blend has saturated near 0.925 OOF.

## What we learned

- Learning rate mattered most. Low LR (3e-5 to 5e-5) lifted convnext from 0.80 to 0.90, and efficientnet is the opposite and needs a high LR.
- Pretrained family matters next. CLIP, SigLIP and SigLIP 2 ViT-B/16 with layer decay 0.75 beat convnext_small by about 0.005 to 0.010 (SigLIP 2 is the best single at 0.9183), and DINOv2 small matched convnext_tiny.
- Resolution, Noisy Student weights, drop path, multi-scale TTA and larger weight decay gave nothing measurable. Mixup and cutmix hurt.
- Shift augmentation costs 0.03 at high LR and about 0.005 at low LR, and its effect on test calls is not predictable (it moved calls toward Rusak for CLIP and away from Rusak for convnext).
- Single-run differences under about 0.005 are noise (per-fold standard deviation is about 0.01). Blends have saturated near 0.925, run 32 added nothing to the five-way blend.
- Rusak is the weak class (F1 about 0.85, recall about 0.82). Aman is about 0.95 and Lainnya about 0.94.
- Training has real run-to-run nondeterminism unless the DataLoader seeding and cuDNN determinism fixes are on (they are now).

## Why the leaderboard is lower than OOF (diagnostics, no test labels used)

- Test images differ from train in format (test is 19.5% WEBP against 11.2%), JPEG quality (66% of test JPEGs sit in quality 70 to 78 against 30% of train), file size and dimensions.
- Reweighting the OOF to the test mix of format, quality and size raises it (blend 0.9203 to 0.9415), so this composition shift does not explain the gap.
- A CLIP embedding classifier tells train from test with AUC 0.87, so the content differs. Test is not farther from train than train is from itself, and near-duplicate overlap is the same (23% against 22%). OOF accuracy is flat across test-likeness levels, so measurable covariate shift does not explain the gap either.
- Possible error pockets are clusters 25, 19 and 17 (about 15% of test) where model confidence drops, and Lainnya, which is predicted for only 1.8% of test against 3.5% of train. Boosting Lainnya costs a lot of OOF (10.8x needed to match the train share, OOF falls from 0.92 to 0.83), so it was not pursued.
- The remaining explanation is label related and cannot be checked without test labels.

## Compute and cost

- Kaggle 2xT4 runs 2.3 to 3.0 hours for ViT-B and costs quota only (about 2.5 hours of weekly quota left after run 32). Modal runs 5 folds in parallel on T4s in about an hour, run 31 cost $5.11, and $4.44 of credit is left.
- Laptop GTX 1650 Ti is too slow (about 970 s per epoch for convnext_small, my benchmark was off by about 7x).
- Five lab Mac minis are available (setup planned Oct 6). Timing must be measured with one real epoch before planning, rough guesses range from 2 to 7 hours per ViT-B fold.
- A GPU request for a shared 3060 and a shared L40 is pending with no answer.

## Risks and open items

- Teammate files with hardcoded test labels of unknown origin score 0.755 to 0.845 on the leaderboard. They are a rules risk and are never used or tuned against here, and Kaggle's auto-pick could select them as the team's final two. Choose the final two submissions manually.
- Next submissions are the six-way blend and run 32 alone.
- Kaggle quota is nearly used up, so any further run would use the Modal credit ($4.44) or the Macs.
- Writeup and notebook cleanup (including the AI declaration) are not done.

## File naming

- Submissions in the project root are named `submission-5fold-focal-<model>-run<N>.csv` for single runs and `submission-blend-run<A>-run<B>-equal.csv` for blends.
- Probabilities are in `archive/probs-run<N>-<model>.zip` or `.npz` with the keys `oof_probs_flip`, `oof_targets`, `oof_filepaths`, `test_probs`, `test_filenames` and `classes`. Compare rows by the last two path parts because Modal and Kaggle prefixes differ.
- `scripts/modal_train.py` runs Modal training (it now supports ViTs through `--layer-decay`, `--norm` and `--multi-scale-tta`), and `scratchpad/` holds the CPU venv and the analysis scripts.
